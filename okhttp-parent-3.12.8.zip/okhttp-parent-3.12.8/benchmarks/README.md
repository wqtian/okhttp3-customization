OkHttp Benchmarks
=======================================

This module allows you to test the performance of HTTP clients.

### Running
  1. If you made modifications to `Benchmark` run `mvn compile`.
  2. Run `mvn exec:exec` to launch a new JVM, which will execute the benchmark.
