/** Support for server-sent events. */
@cocoshttp3.internal.annotations.EverythingIsNonNull
package cocoshttp3.sse;
