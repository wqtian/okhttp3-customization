/** Private support classes for server-sent events. */
@customhttp3.internal.annotations.EverythingIsNonNull
package customhttp3.internal.sse;
