/** An HTTP+HTTP/2 client for Android and Java applications. */
@cocoshttp3.internal.annotations.EverythingIsNonNull
package cocoshttp3;
