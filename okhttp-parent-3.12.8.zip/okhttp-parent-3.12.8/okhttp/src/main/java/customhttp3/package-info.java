/** An HTTP+HTTP/2 client for Android and Java applications. */
@customhttp3.internal.annotations.EverythingIsNonNull
package customhttp3;
