OkHttp DNS over HTTPS Implementation
====================================

This module is an experimental implementation of DNS over HTTPS using OkHttp.
API is not considered stable and may change at any time.
