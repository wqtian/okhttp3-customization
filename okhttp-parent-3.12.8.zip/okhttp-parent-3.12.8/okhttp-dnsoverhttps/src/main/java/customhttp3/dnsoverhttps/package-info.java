/** A DNS over HTTPS implementation for OkHttp. */
@customhttp3.internal.annotations.EverythingIsNonNull
package customhttp3.dnsoverhttps;
